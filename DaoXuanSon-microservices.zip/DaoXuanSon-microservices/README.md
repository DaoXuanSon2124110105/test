# Hệ thống Quản lý vận chuyển / giao hàng – Spring Boot Microservices

Lab 02 – Lập trình Web 3. Đề tài: **Quản lý vận chuyển/giao hàng**.

## Cấu trúc

```
hotenkhongdau-microservices/
├── backend/
│   ├── delivery-service/   # Service 1 – MySQL      – port 8081 – delivery_db
│   └── driver-service/     # Service 2 – SQL Server – port 8082 – driver_db
├── frontend/ (admin, client)
├── database/               # Script tạo database rỗng
├── postman/                # Collection test API
├── .gitignore
└── README.md
```

Các Service còn lại dự kiến: customer-service (8083), assignment-service (8084), payment-service (8085), employee-service (8086).

## Chuẩn bị Database

1. MySQL: chạy `database/delivery_db.mysql.sql` (hoặc tạo database rỗng `delivery_db`).
2. SQL Server: chạy `database/driver_db.sqlserver.sql` trong SSMS (hoặc tạo database rỗng `driver_db`). Cần bật TCP/IP, port 1433, đăng nhập `sa`.
3. Các bảng được Hibernate tự tạo (`spring.jpa.hibernate.ddl-auto=update`).

## Mật khẩu (.env)

Sửa file `.env` trong từng service (file này đã được `.gitignore`, **không** push lên GitHub):

- `backend/delivery-service/.env` → `MYSQL_PASSWORD=...`
- `backend/driver-service/.env` → `SQLSERVER_PASSWORD=...`

## Chạy

```bash
cd backend/delivery-service
mvn clean compile
mvn spring-boot:run        # http://localhost:8081

cd backend/driver-service
mvn clean compile
mvn spring-boot:run        # http://localhost:8082
```

Cần JDK 17+ và Maven. Chạy lệnh trong thư mục của từng service (để đọc đúng file `.env`).

## API

### Delivery Service (8081)

| Method | URL | Chức năng |
|---|---|---|
| GET | /api/delivery-orders?status= | Danh sách đơn (lọc theo trạng thái) |
| GET | /api/delivery-orders/{id} | Chi tiết đơn |
| GET | /api/delivery-orders/tracking/{code} | Tra cứu theo mã vận đơn |
| POST | /api/delivery-orders | Tạo đơn (tự sinh mã vận đơn, trạng thái PENDING) |
| PUT | /api/delivery-orders/{id} | Cập nhật thông tin đơn |
| PUT | /api/delivery-orders/{id}/status | Đổi trạng thái + ghi mốc hành trình |
| DELETE | /api/delivery-orders/{id} | Xóa đơn (chỉ PENDING / CANCELLED) |
| GET/POST/PUT/DELETE | /api/delivery-items[/{id}]?deliveryOrderId= | CRUD hàng hóa trong đơn |
| GET/POST/PUT/DELETE | /api/tracking-events[/{id}]?deliveryOrderId= | CRUD hành trình đơn |

### Driver Service (8082)

| Method | URL | Chức năng |
|---|---|---|
| GET/POST/PUT/DELETE | /api/drivers[/{id}]?status= | CRUD tài xế |
| GET/POST/PUT/DELETE | /api/vehicles[/{id}]?driverId= | CRUD phương tiện |
| GET/POST/PUT/DELETE | /api/driver-shifts[/{id}]?driverId= | CRUD ca làm việc |

Mã trạng thái HTTP: `200` OK, `201` tạo mới, `204` xóa thành công, `400` dữ liệu không hợp lệ, `404` không tìm thấy ID, `409` trùng giá trị unique / bị ràng buộc khóa ngoại.

Quan hệ giữa bảng con và bảng cha gửi dưới dạng `"deliveryOrder": {"id": 1}` hoặc `"driver": {"id": 1}`.

## Test bằng Postman

Import `postman/Lab02_Delivery_Microservices.postman_collection.json`. Thứ tự gợi ý: tạo order → thêm item → đổi status → xem tracking events; tạo driver → tạo vehicle → tạo shift.

## Git

```bash
git init
git branch -M main
git add .
git commit -m "Khoi tao do an Microservices"
git remote add origin https://github.com/USERNAME/hotenkhongdau-microservices.git
git push -u origin main
```
