package com.example.deliveryservice.repository;

import com.example.deliveryservice.entity.DeliveryOrder;
import com.example.deliveryservice.entity.DeliveryStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface DeliveryOrderRepository extends JpaRepository<DeliveryOrder, Long> {

    List<DeliveryOrder> findByStatus(DeliveryStatus status);

    Optional<DeliveryOrder> findByTrackingCode(String trackingCode);

    boolean existsByTrackingCode(String trackingCode);
}
