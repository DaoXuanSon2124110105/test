package com.example.deliveryservice.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Table(name = "delivery_items")
@Getter
@Setter
@NoArgsConstructor
public class DeliveryItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "itemName is required")
    @Size(max = 150)
    @Column(name = "item_name", nullable = false, length = 150)
    private String itemName;

    @NotNull(message = "quantity is required")
    @Min(value = 1, message = "quantity must be >= 1")
    @Column(nullable = false)
    private Integer quantity;

    @NotNull(message = "weight is required")
    @DecimalMin(value = "0.0", message = "weight must be >= 0")
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal weight;

    @DecimalMin(value = "0.0", message = "declaredValue must be >= 0")
    @Column(name = "declared_value", precision = 15, scale = 2)
    private BigDecimal declaredValue;

    @NotNull(message = "deliveryOrder is required")
    @ManyToOne(optional = false)
    @JoinColumn(name = "delivery_order_id", nullable = false)
    @JsonIgnoreProperties({"items", "trackingEvents"})
    private DeliveryOrder deliveryOrder;
}
