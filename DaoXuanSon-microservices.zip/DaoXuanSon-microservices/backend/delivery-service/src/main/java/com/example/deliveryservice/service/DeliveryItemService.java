package com.example.deliveryservice.service;

import com.example.deliveryservice.entity.*;
import com.example.deliveryservice.exception.BadRequestException;
import com.example.deliveryservice.exception.ResourceNotFoundException;
import com.example.deliveryservice.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class DeliveryItemService {

    private final DeliveryItemRepository repository;
    private final DeliveryOrderRepository deliveryOrderRepository;

    public DeliveryItemService(DeliveryItemRepository repository, DeliveryOrderRepository deliveryOrderRepository) {
        this.repository = repository;
        this.deliveryOrderRepository = deliveryOrderRepository;
    }

    public List<DeliveryItem> getAll(Long deliveryOrderId) {
        return deliveryOrderId == null ? repository.findAll() : repository.findByDeliveryOrderId(deliveryOrderId);
    }

    public DeliveryItem getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("DeliveryItem not found with id " + id));
    }

    @Transactional
    public DeliveryItem create(DeliveryItem entity) {
        entity.setId(null);
        entity.setDeliveryOrder(resolveDeliveryOrder(entity.getDeliveryOrder()));
        return repository.save(entity);
    }

    @Transactional
    public DeliveryItem update(Long id, DeliveryItem input) {
        DeliveryItem existing = getById(id);
        existing.setItemName(input.getItemName());
        existing.setQuantity(input.getQuantity());
        existing.setWeight(input.getWeight());
        existing.setDeclaredValue(input.getDeclaredValue());
        if (input.getDeliveryOrder() != null) {
            existing.setDeliveryOrder(resolveDeliveryOrder(input.getDeliveryOrder()));
        }
        return repository.save(existing);
    }

    @Transactional
    public void delete(Long id) {
        repository.delete(getById(id));
    }

    private DeliveryOrder resolveDeliveryOrder(DeliveryOrder ref) {
        if (ref == null || ref.getId() == null) {
            throw new BadRequestException("deliveryOrder.id is required");
        }
        return deliveryOrderRepository.findById(ref.getId())
                .orElseThrow(() -> new ResourceNotFoundException("DeliveryOrder not found with id " + ref.getId()));
    }
}
