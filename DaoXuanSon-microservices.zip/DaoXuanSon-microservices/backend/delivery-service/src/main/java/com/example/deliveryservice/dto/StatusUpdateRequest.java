package com.example.deliveryservice.dto;

import com.example.deliveryservice.entity.DeliveryStatus;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class StatusUpdateRequest {

    @NotNull(message = "status is required")
    private DeliveryStatus status;

    @Size(max = 255)
    private String location;

    @Size(max = 500)
    private String description;
}
