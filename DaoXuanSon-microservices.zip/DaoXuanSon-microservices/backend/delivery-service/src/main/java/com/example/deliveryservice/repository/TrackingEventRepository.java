package com.example.deliveryservice.repository;

import com.example.deliveryservice.entity.TrackingEvent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TrackingEventRepository extends JpaRepository<TrackingEvent, Long> {

    List<TrackingEvent> findByDeliveryOrderIdOrderByEventTimeAsc(Long deliveryOrderId);
}
