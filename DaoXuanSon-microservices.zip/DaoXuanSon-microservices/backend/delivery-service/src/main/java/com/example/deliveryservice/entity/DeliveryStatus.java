package com.example.deliveryservice.entity;

public enum DeliveryStatus {
    PENDING,      // Cho xac nhan / cho phan cong
    ASSIGNED,     // Da phan cong tai xe
    PICKED_UP,    // Da lay hang
    IN_TRANSIT,   // Dang van chuyen
    DELIVERED,    // Giao thanh cong
    FAILED,       // Giao that bai
    CANCELLED     // Da huy
}
