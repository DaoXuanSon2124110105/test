package com.example.deliveryservice.repository;

import com.example.deliveryservice.entity.DeliveryItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DeliveryItemRepository extends JpaRepository<DeliveryItem, Long> {

    List<DeliveryItem> findByDeliveryOrderId(Long deliveryOrderId);
}
