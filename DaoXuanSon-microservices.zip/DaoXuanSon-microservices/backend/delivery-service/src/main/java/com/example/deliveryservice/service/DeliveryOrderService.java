package com.example.deliveryservice.service;

import com.example.deliveryservice.dto.StatusUpdateRequest;
import com.example.deliveryservice.entity.DeliveryOrder;
import com.example.deliveryservice.entity.DeliveryStatus;
import com.example.deliveryservice.entity.TrackingEvent;
import com.example.deliveryservice.exception.BadRequestException;
import com.example.deliveryservice.exception.ResourceNotFoundException;
import com.example.deliveryservice.repository.DeliveryOrderRepository;
import com.example.deliveryservice.repository.TrackingEventRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class DeliveryOrderService {

    private final DeliveryOrderRepository repository;
    private final TrackingEventRepository eventRepository;

    public DeliveryOrderService(DeliveryOrderRepository repository,
                                TrackingEventRepository eventRepository) {
        this.repository = repository;
        this.eventRepository = eventRepository;
    }

    public List<DeliveryOrder> getAll(DeliveryStatus status) {
        return status == null ? repository.findAll() : repository.findByStatus(status);
    }

    public DeliveryOrder getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Delivery order not found with id " + id));
    }

    public DeliveryOrder getByTrackingCode(String trackingCode) {
        return repository.findByTrackingCode(trackingCode)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Delivery order not found with tracking code " + trackingCode));
    }

    @Transactional
    public DeliveryOrder create(DeliveryOrder order) {
        order.setId(null);
        order.setTrackingCode(generateTrackingCode());
        order.setStatus(DeliveryStatus.PENDING);
        if (order.getCodAmount() == null) {
            order.setCodAmount(BigDecimal.ZERO);
        }
        DeliveryOrder saved = repository.save(order);
        addEvent(saved, DeliveryStatus.PENDING, null, "Đơn vận chuyển được tạo");
        return saved;
    }

    @Transactional
    public DeliveryOrder update(Long id, DeliveryOrder input) {
        DeliveryOrder existing = getById(id);
        if (existing.getStatus() == DeliveryStatus.DELIVERED
                || existing.getStatus() == DeliveryStatus.CANCELLED) {
            throw new BadRequestException("Order is " + existing.getStatus() + " and can no longer be edited");
        }
        existing.setCustomerId(input.getCustomerId());
        existing.setSenderName(input.getSenderName());
        existing.setSenderPhone(input.getSenderPhone());
        existing.setSenderAddress(input.getSenderAddress());
        existing.setReceiverName(input.getReceiverName());
        existing.setReceiverPhone(input.getReceiverPhone());
        existing.setReceiverAddress(input.getReceiverAddress());
        existing.setShippingFee(input.getShippingFee());
        existing.setCodAmount(input.getCodAmount() == null ? BigDecimal.ZERO : input.getCodAmount());
        existing.setTotalWeight(input.getTotalWeight());
        existing.setNote(input.getNote());
        return repository.save(existing);
    }

    /** Cap nhat trang thai don hang va ghi them 1 moc hanh trinh. */
    @Transactional
    public DeliveryOrder updateStatus(Long id, StatusUpdateRequest request) {
        DeliveryOrder order = getById(id);
        DeliveryStatus current = order.getStatus();
        DeliveryStatus next = request.getStatus();

        if (current == DeliveryStatus.DELIVERED || current == DeliveryStatus.CANCELLED) {
            throw new BadRequestException("Order is already " + current + ", status cannot be changed");
        }
        if (next == DeliveryStatus.CANCELLED
                && current != DeliveryStatus.PENDING && current != DeliveryStatus.ASSIGNED) {
            throw new BadRequestException("Order can only be cancelled before the goods are picked up");
        }

        order.setStatus(next);
        DeliveryOrder saved = repository.save(order);
        String description = request.getDescription() != null
                ? request.getDescription() : "Trạng thái đơn hàng: " + next;
        addEvent(saved, next, request.getLocation(), description);
        return saved;
    }

    @Transactional
    public void delete(Long id) {
        DeliveryOrder order = getById(id);
        if (order.getStatus() != DeliveryStatus.PENDING && order.getStatus() != DeliveryStatus.CANCELLED) {
            throw new BadRequestException("Only PENDING or CANCELLED orders can be deleted");
        }
        repository.delete(order); // cascade REMOVE: xoa luon items va tracking events
    }

    private void addEvent(DeliveryOrder order, DeliveryStatus status, String location, String description) {
        TrackingEvent event = new TrackingEvent();
        event.setDeliveryOrder(order);
        event.setStatus(status);
        event.setLocation(location);
        event.setDescription(description);
        event.setEventTime(LocalDateTime.now());
        eventRepository.save(event);
    }

    private String generateTrackingCode() {
        String code;
        do {
            code = "VC" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMddHHmmss"))
                    + ThreadLocalRandom.current().nextInt(1000, 10000);
        } while (repository.existsByTrackingCode(code));
        return code;
    }
}
