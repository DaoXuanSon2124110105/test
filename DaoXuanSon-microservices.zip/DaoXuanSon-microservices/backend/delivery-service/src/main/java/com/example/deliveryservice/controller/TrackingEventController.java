package com.example.deliveryservice.controller;

import com.example.deliveryservice.entity.*;
import com.example.deliveryservice.service.TrackingEventService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tracking-events")
public class TrackingEventController {

    private final TrackingEventService service;

    public TrackingEventController(TrackingEventService service) {
        this.service = service;
    }

    @GetMapping
    public List<TrackingEvent> getAll(@RequestParam(required = false) Long deliveryOrderId) {
        return service.getAll(deliveryOrderId);
    }

    @GetMapping("/{id}")
    public TrackingEvent getById(@PathVariable Long id) {
        return service.getById(id);
    }

    @PostMapping
    public ResponseEntity<TrackingEvent> create(@Valid @RequestBody TrackingEvent body) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(body));
    }

    @PutMapping("/{id}")
    public TrackingEvent update(@PathVariable Long id, @Valid @RequestBody TrackingEvent body) {
        return service.update(id, body);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
