package com.example.deliveryservice.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

/** Mot moc trong hanh trinh van chuyen cua don hang. */
@Entity
@Table(name = "tracking_events")
@Getter
@Setter
@NoArgsConstructor
public class TrackingEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "status is required")
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private DeliveryStatus status;

    @Size(max = 255)
    private String location;

    @Size(max = 500)
    @Column(length = 500)
    private String description;

    @Column(name = "event_time", nullable = false)
    private LocalDateTime eventTime = LocalDateTime.now();

    @NotNull(message = "deliveryOrder is required")
    @ManyToOne(optional = false)
    @JoinColumn(name = "delivery_order_id", nullable = false)
    @JsonIgnoreProperties({"items", "trackingEvents"})
    private DeliveryOrder deliveryOrder;
}
