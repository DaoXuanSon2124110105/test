package com.example.deliveryservice.controller;

import com.example.deliveryservice.dto.StatusUpdateRequest;
import com.example.deliveryservice.entity.DeliveryOrder;
import com.example.deliveryservice.entity.DeliveryStatus;
import com.example.deliveryservice.service.DeliveryOrderService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/delivery-orders")
public class DeliveryOrderController {

    private final DeliveryOrderService service;

    public DeliveryOrderController(DeliveryOrderService service) {
        this.service = service;
    }

    @GetMapping
    public List<DeliveryOrder> getAll(@RequestParam(required = false) DeliveryStatus status) {
        return service.getAll(status);
    }

    @GetMapping("/{id}")
    public DeliveryOrder getById(@PathVariable Long id) {
        return service.getById(id);
    }

    /** Tra cuu van don theo ma. */
    @GetMapping("/tracking/{trackingCode}")
    public DeliveryOrder getByTrackingCode(@PathVariable String trackingCode) {
        return service.getByTrackingCode(trackingCode);
    }

    @PostMapping
    public ResponseEntity<DeliveryOrder> create(@Valid @RequestBody DeliveryOrder body) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(body));
    }

    @PutMapping("/{id}")
    public DeliveryOrder update(@PathVariable Long id, @Valid @RequestBody DeliveryOrder body) {
        return service.update(id, body);
    }

    @PutMapping("/{id}/status")
    public DeliveryOrder updateStatus(@PathVariable Long id, @Valid @RequestBody StatusUpdateRequest body) {
        return service.updateStatus(id, body);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
