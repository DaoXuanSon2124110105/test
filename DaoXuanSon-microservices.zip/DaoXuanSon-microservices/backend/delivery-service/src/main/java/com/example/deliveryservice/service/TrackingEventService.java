package com.example.deliveryservice.service;

import com.example.deliveryservice.entity.*;
import com.example.deliveryservice.exception.BadRequestException;
import com.example.deliveryservice.exception.ResourceNotFoundException;
import com.example.deliveryservice.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class TrackingEventService {

    private final TrackingEventRepository repository;
    private final DeliveryOrderRepository deliveryOrderRepository;

    public TrackingEventService(TrackingEventRepository repository, DeliveryOrderRepository deliveryOrderRepository) {
        this.repository = repository;
        this.deliveryOrderRepository = deliveryOrderRepository;
    }

    public List<TrackingEvent> getAll(Long deliveryOrderId) {
        return deliveryOrderId == null ? repository.findAll() : repository.findByDeliveryOrderIdOrderByEventTimeAsc(deliveryOrderId);
    }

    public TrackingEvent getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("TrackingEvent not found with id " + id));
    }

    @Transactional
    public TrackingEvent create(TrackingEvent entity) {
        entity.setId(null);
        entity.setDeliveryOrder(resolveDeliveryOrder(entity.getDeliveryOrder()));
        return repository.save(entity);
    }

    @Transactional
    public TrackingEvent update(Long id, TrackingEvent input) {
        TrackingEvent existing = getById(id);
        existing.setStatus(input.getStatus());
        existing.setLocation(input.getLocation());
        existing.setDescription(input.getDescription());
        existing.setEventTime(input.getEventTime());
        if (input.getDeliveryOrder() != null) {
            existing.setDeliveryOrder(resolveDeliveryOrder(input.getDeliveryOrder()));
        }
        return repository.save(existing);
    }

    @Transactional
    public void delete(Long id) {
        repository.delete(getById(id));
    }

    private DeliveryOrder resolveDeliveryOrder(DeliveryOrder ref) {
        if (ref == null || ref.getId() == null) {
            throw new BadRequestException("deliveryOrder.id is required");
        }
        return deliveryOrderRepository.findById(ref.getId())
                .orElseThrow(() -> new ResourceNotFoundException("DeliveryOrder not found with id " + ref.getId()));
    }
}
