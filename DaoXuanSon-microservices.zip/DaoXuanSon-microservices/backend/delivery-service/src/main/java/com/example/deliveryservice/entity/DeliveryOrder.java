package com.example.deliveryservice.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "delivery_orders")
@Getter
@Setter
@NoArgsConstructor
public class DeliveryOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Ma van don, he thong tu sinh khi tao don. */
    @Column(name = "tracking_code", nullable = false, unique = true, length = 30, updatable = false)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String trackingCode;

    /** Tham chieu logic den Customer Service (khong co khoa ngoai vat ly giua 2 database). */
    @NotNull(message = "customerId is required")
    @Column(name = "customer_id", nullable = false)
    private Long customerId;

    @NotBlank(message = "senderName is required")
    @Size(max = 100)
    @Column(name = "sender_name", nullable = false, length = 100)
    private String senderName;

    @NotBlank(message = "senderPhone is required")
    @Pattern(regexp = "^(0|\\+84)[0-9]{9,10}$", message = "senderPhone is invalid")
    @Column(name = "sender_phone", nullable = false, length = 20)
    private String senderPhone;

    @NotBlank(message = "senderAddress is required")
    @Size(max = 255)
    @Column(name = "sender_address", nullable = false)
    private String senderAddress;

    @NotBlank(message = "receiverName is required")
    @Size(max = 100)
    @Column(name = "receiver_name", nullable = false, length = 100)
    private String receiverName;

    @NotBlank(message = "receiverPhone is required")
    @Pattern(regexp = "^(0|\\+84)[0-9]{9,10}$", message = "receiverPhone is invalid")
    @Column(name = "receiver_phone", nullable = false, length = 20)
    private String receiverPhone;

    @NotBlank(message = "receiverAddress is required")
    @Size(max = 255)
    @Column(name = "receiver_address", nullable = false)
    private String receiverAddress;

    @NotNull(message = "shippingFee is required")
    @DecimalMin(value = "0.0", message = "shippingFee must be >= 0")
    @Column(name = "shipping_fee", nullable = false, precision = 15, scale = 2)
    private BigDecimal shippingFee;

    /** Tien thu ho (COD). */
    @DecimalMin(value = "0.0", message = "codAmount must be >= 0")
    @Column(name = "cod_amount", nullable = false, precision = 15, scale = 2)
    private BigDecimal codAmount = BigDecimal.ZERO;

    @DecimalMin(value = "0.0", message = "totalWeight must be >= 0")
    @Column(name = "total_weight", precision = 10, scale = 2)
    private BigDecimal totalWeight;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private DeliveryStatus status = DeliveryStatus.PENDING;

    @Size(max = 500)
    @Column(length = 500)
    private String note;

    @Column(name = "created_at", nullable = false, updatable = false)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "deliveryOrder", cascade = CascadeType.REMOVE)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @JsonIgnoreProperties("deliveryOrder")
    private List<DeliveryItem> items = new ArrayList<>();

    @OneToMany(mappedBy = "deliveryOrder", cascade = CascadeType.REMOVE)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @JsonIgnoreProperties("deliveryOrder")
    private List<TrackingEvent> trackingEvents = new ArrayList<>();

    @PrePersist
    void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = createdAt;
    }

    @PreUpdate
    void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
