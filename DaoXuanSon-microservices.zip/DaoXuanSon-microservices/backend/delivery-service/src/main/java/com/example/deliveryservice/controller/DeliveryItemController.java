package com.example.deliveryservice.controller;

import com.example.deliveryservice.entity.*;
import com.example.deliveryservice.service.DeliveryItemService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/delivery-items")
public class DeliveryItemController {

    private final DeliveryItemService service;

    public DeliveryItemController(DeliveryItemService service) {
        this.service = service;
    }

    @GetMapping
    public List<DeliveryItem> getAll(@RequestParam(required = false) Long deliveryOrderId) {
        return service.getAll(deliveryOrderId);
    }

    @GetMapping("/{id}")
    public DeliveryItem getById(@PathVariable Long id) {
        return service.getById(id);
    }

    @PostMapping
    public ResponseEntity<DeliveryItem> create(@Valid @RequestBody DeliveryItem body) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(body));
    }

    @PutMapping("/{id}")
    public DeliveryItem update(@PathVariable Long id, @Valid @RequestBody DeliveryItem body) {
        return service.update(id, body);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
