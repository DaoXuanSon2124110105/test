package com.example.driverservice.entity;

public enum VehicleType {
    MOTORBIKE, VAN, TRUCK
}
