package com.example.driverservice.entity;

public enum DriverStatus {
    AVAILABLE,   // San sang nhan don
    BUSY,        // Dang giao hang
    OFF_DUTY,    // Nghi
    SUSPENDED    // Tam khoa
}
