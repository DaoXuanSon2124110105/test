package com.example.driverservice.service;

import com.example.driverservice.entity.*;
import com.example.driverservice.exception.BadRequestException;
import com.example.driverservice.exception.ResourceNotFoundException;
import com.example.driverservice.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class DriverService {

    private final DriverRepository repository;

    public DriverService(DriverRepository repository) {
        this.repository = repository;
    }

    public List<Driver> getAll(DriverStatus status) {
        return status == null ? repository.findAll() : repository.findByStatus(status);
    }

    public Driver getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Driver not found with id " + id));
    }

    @Transactional
    public Driver create(Driver entity) {
        entity.setId(null);
        return repository.save(entity);
    }

    @Transactional
    public Driver update(Long id, Driver input) {
        Driver existing = getById(id);
        existing.setFullName(input.getFullName());
        existing.setPhone(input.getPhone());
        existing.setEmail(input.getEmail());
        existing.setCitizenId(input.getCitizenId());
        existing.setLicenseNumber(input.getLicenseNumber());
        existing.setLicenseClass(input.getLicenseClass());
        existing.setStatus(input.getStatus());
        existing.setHireDate(input.getHireDate());
        return repository.save(existing);
    }

    @Transactional
    public void delete(Long id) {
        repository.delete(getById(id));
    }
}
