package com.example.driverservice.controller;

import com.example.driverservice.entity.*;
import com.example.driverservice.service.DriverShiftService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/driver-shifts")
public class DriverShiftController {

    private final DriverShiftService service;

    public DriverShiftController(DriverShiftService service) {
        this.service = service;
    }

    @GetMapping
    public List<DriverShift> getAll(@RequestParam(required = false) Long driverId) {
        return service.getAll(driverId);
    }

    @GetMapping("/{id}")
    public DriverShift getById(@PathVariable Long id) {
        return service.getById(id);
    }

    @PostMapping
    public ResponseEntity<DriverShift> create(@Valid @RequestBody DriverShift body) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(body));
    }

    @PutMapping("/{id}")
    public DriverShift update(@PathVariable Long id, @Valid @RequestBody DriverShift body) {
        return service.update(id, body);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
