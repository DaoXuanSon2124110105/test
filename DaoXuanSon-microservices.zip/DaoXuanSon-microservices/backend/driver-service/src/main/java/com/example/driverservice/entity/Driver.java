package com.example.driverservice.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "drivers")
@Getter
@Setter
@NoArgsConstructor
public class Driver {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "fullName is required")
    @Size(max = 100)
    @Nationalized
    @Column(name = "full_name", nullable = false, length = 100)
    private String fullName;

    @NotBlank(message = "phone is required")
    @Pattern(regexp = "^(0|\\+84)[0-9]{9,10}$", message = "phone is invalid")
    @Column(nullable = false, unique = true, length = 20)
    private String phone;

    @Email(message = "email is invalid")
    @Size(max = 100)
    @Column(length = 100)
    private String email;

    @NotBlank(message = "citizenId is required")
    @Pattern(regexp = "^[0-9]{9}$|^[0-9]{12}$", message = "citizenId must have 9 or 12 digits")
    @Column(name = "citizen_id", nullable = false, unique = true, length = 12)
    private String citizenId;

    @NotBlank(message = "licenseNumber is required")
    @Size(max = 30)
    @Column(name = "license_number", nullable = false, unique = true, length = 30)
    private String licenseNumber;

    @NotBlank(message = "licenseClass is required")
    @Size(max = 10)
    @Column(name = "license_class", nullable = false, length = 10)
    private String licenseClass;

    @NotNull(message = "status is required")
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private DriverStatus status = DriverStatus.AVAILABLE;

    @Column(name = "hire_date")
    private LocalDate hireDate;

    @Column(name = "created_at", nullable = false, updatable = false)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private LocalDateTime createdAt;

    @OneToMany(mappedBy = "driver")
    @JsonIgnore
    private List<Vehicle> vehicles = new ArrayList<>();

    @OneToMany(mappedBy = "driver")
    @JsonIgnore
    private List<DriverShift> shifts = new ArrayList<>();

    @PrePersist
    void onCreate() {
        createdAt = LocalDateTime.now();
    }
}
