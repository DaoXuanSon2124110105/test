package com.example.driverservice.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;

import java.math.BigDecimal;

@Entity
@Table(name = "vehicles")
@Getter
@Setter
@NoArgsConstructor
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "plateNumber is required")
    @Size(max = 15)
    @Column(name = "plate_number", nullable = false, unique = true, length = 15)
    private String plateNumber;

    @NotNull(message = "vehicleType is required")
    @Enumerated(EnumType.STRING)
    @Column(name = "vehicle_type", nullable = false, length = 20)
    private VehicleType vehicleType;

    @Size(max = 50)
    @Nationalized
    @Column(length = 50)
    private String brand;

    @NotNull(message = "capacityKg is required")
    @Positive(message = "capacityKg must be > 0")
    @Column(name = "capacity_kg", nullable = false, precision = 10, scale = 2)
    private BigDecimal capacityKg;

    @NotNull(message = "status is required")
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private VehicleStatus status = VehicleStatus.ACTIVE;

    /** Tai xe duoc gan xe (co the null neu xe chua gan). */
    @ManyToOne
    @JoinColumn(name = "driver_id")
    private Driver driver;
}
