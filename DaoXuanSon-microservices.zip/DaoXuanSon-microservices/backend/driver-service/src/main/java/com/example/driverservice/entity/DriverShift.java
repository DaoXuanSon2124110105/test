package com.example.driverservice.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;

import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "driver_shifts")
@Getter
@Setter
@NoArgsConstructor
public class DriverShift {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "shiftDate is required")
    @Column(name = "shift_date", nullable = false)
    private LocalDate shiftDate;

    @NotNull(message = "startTime is required")
    @Column(name = "start_time", nullable = false)
    private LocalTime startTime;

    @NotNull(message = "endTime is required")
    @Column(name = "end_time", nullable = false)
    private LocalTime endTime;

    @Size(max = 100)
    @Nationalized
    @Column(name = "working_area", length = 100)
    private String workingArea;

    @Size(max = 255)
    @Nationalized
    private String note;

    @NotNull(message = "driver is required")
    @ManyToOne(optional = false)
    @JoinColumn(name = "driver_id", nullable = false)
    private Driver driver;

    @JsonIgnore
    @AssertTrue(message = "endTime must be after startTime")
    public boolean isValidTimeRange() {
        return startTime == null || endTime == null || endTime.isAfter(startTime);
    }
}
