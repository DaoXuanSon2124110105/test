package com.example.driverservice.entity;

public enum VehicleStatus {
    ACTIVE, MAINTENANCE, INACTIVE
}
