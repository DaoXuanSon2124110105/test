package com.example.driverservice.service;

import com.example.driverservice.entity.*;
import com.example.driverservice.exception.BadRequestException;
import com.example.driverservice.exception.ResourceNotFoundException;
import com.example.driverservice.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class DriverShiftService {

    private final DriverShiftRepository repository;
    private final DriverRepository driverRepository;

    public DriverShiftService(DriverShiftRepository repository, DriverRepository driverRepository) {
        this.repository = repository;
        this.driverRepository = driverRepository;
    }

    public List<DriverShift> getAll(Long driverId) {
        return driverId == null ? repository.findAll() : repository.findByDriverId(driverId);
    }

    public DriverShift getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("DriverShift not found with id " + id));
    }

    @Transactional
    public DriverShift create(DriverShift entity) {
        entity.setId(null);
        entity.setDriver(resolveDriver(entity.getDriver()));
        return repository.save(entity);
    }

    @Transactional
    public DriverShift update(Long id, DriverShift input) {
        DriverShift existing = getById(id);
        existing.setShiftDate(input.getShiftDate());
        existing.setStartTime(input.getStartTime());
        existing.setEndTime(input.getEndTime());
        existing.setWorkingArea(input.getWorkingArea());
        existing.setNote(input.getNote());
        if (input.getDriver() != null) {
            existing.setDriver(resolveDriver(input.getDriver()));
        }
        return repository.save(existing);
    }

    @Transactional
    public void delete(Long id) {
        repository.delete(getById(id));
    }

    private Driver resolveDriver(Driver ref) {
        if (ref == null || ref.getId() == null) {
            throw new BadRequestException("driver.id is required");
        }
        return driverRepository.findById(ref.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Driver not found with id " + ref.getId()));
    }
}
