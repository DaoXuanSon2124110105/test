package com.example.driverservice.repository;

import com.example.driverservice.entity.DriverShift;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DriverShiftRepository extends JpaRepository<DriverShift, Long> {

    List<DriverShift> findByDriverId(Long driverId);
}
