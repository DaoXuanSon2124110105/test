package com.example.driverservice.service;

import com.example.driverservice.entity.*;
import com.example.driverservice.exception.BadRequestException;
import com.example.driverservice.exception.ResourceNotFoundException;
import com.example.driverservice.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class VehicleService {

    private final VehicleRepository repository;
    private final DriverRepository driverRepository;

    public VehicleService(VehicleRepository repository, DriverRepository driverRepository) {
        this.repository = repository;
        this.driverRepository = driverRepository;
    }

    public List<Vehicle> getAll(Long driverId) {
        return driverId == null ? repository.findAll() : repository.findByDriverId(driverId);
    }

    public Vehicle getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found with id " + id));
    }

    @Transactional
    public Vehicle create(Vehicle entity) {
        entity.setId(null);
        entity.setDriver(resolveDriver(entity.getDriver()));
        return repository.save(entity);
    }

    @Transactional
    public Vehicle update(Long id, Vehicle input) {
        Vehicle existing = getById(id);
        existing.setPlateNumber(input.getPlateNumber());
        existing.setVehicleType(input.getVehicleType());
        existing.setBrand(input.getBrand());
        existing.setCapacityKg(input.getCapacityKg());
        existing.setStatus(input.getStatus());
        existing.setDriver(resolveDriver(input.getDriver()));
        return repository.save(existing);
    }

    @Transactional
    public void delete(Long id) {
        repository.delete(getById(id));
    }

    private Driver resolveDriver(Driver ref) {
        if (ref == null || ref.getId() == null) {
            return null;
        }
        return driverRepository.findById(ref.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Driver not found with id " + ref.getId()));
    }
}
