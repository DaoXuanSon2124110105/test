-- Chay trong SQL Server Management Studio (SSMS)
IF DB_ID('driver_db') IS NULL
    CREATE DATABASE driver_db;
GO
