-- Chay trong MySQL (phpMyAdmin / MySQL Workbench)
CREATE DATABASE IF NOT EXISTS delivery_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
